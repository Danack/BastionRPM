monit-5.8.1-CentOS
==================

Spec file valid for compiling monit 5.8.1 for CentOS. 

# Download sources with 
```
spectool -g monit.spec 
```

# Build with 
```
rpmbuild -bs monit.spec
```

